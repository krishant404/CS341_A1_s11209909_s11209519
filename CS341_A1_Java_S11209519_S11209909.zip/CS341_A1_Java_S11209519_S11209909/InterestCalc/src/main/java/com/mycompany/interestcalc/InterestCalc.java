

package com.mycompany.interestcalc;


public class InterestCalc {

    public static double computeLoanInterest(int loanType, int yearLoan, double loanAmount) {
        // Loan interest calculation logic as per loan type, year, and amount
        if (loanAmount <= 0 || yearLoan <= 0) {
            return -1; // Invalid loan amount or year
        }

        switch (loanType) {
            case 1:
                if (loanAmount < 100000) {
                    if (yearLoan <= 5) return loanAmount * 0.08;
                    else if (yearLoan <= 10) return loanAmount * 0.065;
                    else return loanAmount * 0.055;
                } else if (loanAmount < 500000) {
                    if (yearLoan <= 10) return loanAmount * 0.065;
                    else return loanAmount * 0.055;
                } else {
                    return loanAmount * 0.055;
                }
            case 2:
                if (loanAmount < 100000) {
                    if (yearLoan <= 5) return loanAmount * 0.12;
                    else if (yearLoan <= 10) return loanAmount * 0.085;
                    else return loanAmount * 0.07;
                } else if (loanAmount < 500000) {
                    if (yearLoan <= 10) return loanAmount * 0.085;
                    else return loanAmount * 0.07;
                } else {
                    return loanAmount * 0.07;
                }
            default:
                return -1; // Invalid loan type
        }
    }

    public static void runTestCase(int testCaseID, int loanType, int yearLoan, double loanAmount, double expectedOutcome) {
        double actualOutcome = computeLoanInterest(loanType, yearLoan, loanAmount);
        
        System.out.println("Test Case " + testCaseID + ": ");
        System.out.println("Loan Type: " + loanType + ", Year Loan: " + yearLoan + ", Loan Amount: " + loanAmount);
        System.out.println("Expected Outcome: " + expectedOutcome);
        System.out.println("Actual Outcome: " + actualOutcome);
        
        if (actualOutcome == expectedOutcome) {
            System.out.println("Test Passed\n");
        } else {
            System.out.println("Test Failed\n");
        }
    }

    public static void main(String[] args) {
        // Equivalence Partitioning (EP) Test Cases
        System.out.println("Running Equivalence Partitioning (EP) Test Cases...");
        runTestCase(1, 1, 5, 50000, 50000 * 0.08); // EP_01
        runTestCase(2, 1, 7, 50000, 50000 * 0.065); // EP_02
        runTestCase(3, 1, 11, 50000, 50000 * 0.055); // EP_03
        runTestCase(4, 1, 5, 300000, 300000 * 0.065); // EP_04
        runTestCase(5, 1, 12, 550000, 550000 * 0.055); // EP_05
        runTestCase(6, 2, 4, 80000, 80000 * 0.12); // EP_06
        runTestCase(7, 2, 6, 80000, 80000 * 0.085); // EP_07
        runTestCase(8, 2, 11, 80000, 80000 * 0.07); // EP_08
        runTestCase(9, 2, 5, 300000, 300000 * 0.085); // EP_09
        runTestCase(10, 2, 11, 550000, 550000 * 0.07); // EP_10

        // Invalid EP Test Cases
        runTestCase(11, 1, 5, -50000, -1); // EP_11
        runTestCase(12, 1, -3, 50000, -1); // EP_12
        runTestCase(13, 1, 0, 50000, -1); // EP_13
        runTestCase(14, 2, 5, -50000, -1); // EP_14
        runTestCase(15, 2, -3, 50000, -1); // EP_15
        runTestCase(16, 2, 0, 80000, -1); // EP_16
        runTestCase(17, 0, 5, 50000, -1); // EP_17
        runTestCase(18, 3, 5, 80000, -1); // EP_18
        runTestCase(19, 2, 10, 300000, -1); // EP_19

        // Boundary Value Analysis (BVA) Test Cases
        System.out.println("Running Boundary Value Analysis (BVA) Test Cases...");
        runTestCase(20, 1, 5, 99999, 99999 * 0.08); // BVA_01
        runTestCase(21, 1, 5, 100000, 100000 * 0.065); // BVA_02
        runTestCase(22, 1, 5, 100001, 100001 * 0.065); // BVA_03
        runTestCase(23, 1, 6, 99999, 99999 * 0.065); // BVA_04
        runTestCase(24, 1, 10, 99999, 99999 * 0.065); // BVA_05
        runTestCase(25, 1, 10, 100000, 100000 * 0.065); // BVA_06
        runTestCase(26, 1, 11, 99999, 99999 * 0.055); // BVA_07
        runTestCase(27, 1, 11, 100000, 100000 * 0.055); // BVA_08
        runTestCase(28, 1, 11, 500000, 500000 * 0.055); // BVA_09
        runTestCase(29, 1, 10, 499999, 499999 * 0.065); // BVA_10
        runTestCase(30, 1, 11, 500001, 500001 * 0.055); // BVA_11

        // Invalid BVA Test Cases
        runTestCase(31, 1, 5, 0, -1); // BVA_23
        runTestCase(32, 1, 5, -1, -1); // BVA_24
        runTestCase(33, 1, -1, 50000, -1); // BVA_25
        runTestCase(34, 1, 0, 50000, -1); // BVA_26
        runTestCase(35, 2, 5, 0, -1); // BVA_27
        runTestCase(36, 2, 5, -1, -1); // BVA_28
        runTestCase(37, 2, -1, 50000, -1); // BVA_29
        runTestCase(38, 2, 0, 50000, -1); // BVA_30
    }
}

